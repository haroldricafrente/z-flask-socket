#ifndef CONFIG_H
#define CONFIG_H

// ===== Wi-Fi Credentials =====
// Uncomment the network you want to use

// #define WIFI_SSID "BawalAngHappy"
// #define WIFI_PASSWORD "0987654321"

#define WIFI_SSID "OT7"
#define WIFI_PASSWORD "dIk0aLAm"

// #define WIFI_SSID "Mushkin123"
// #define WIFI_PASSWORD "123456789"

// ===== Server Configuration =====
const char* serverURL = "http://52.64.254.252/data";
const char* apiKey = "099d1361a9dca0691d9c41d13c6e9e9513325f4696814bf855f90fd3954ac023";  // Replace with your actual API key

#endif // CONFIG_H
